import { cn } from "@/lib/utils";

export function NexoLogo({ className, size = "md" }: { className?: string; size?: "sm" | "md" | "lg" }) {
  const text = size === "lg" ? "text-5xl sm:text-7xl" : size === "sm" ? "text-lg" : "text-2xl";
  return (
    <span className={cn("font-display font-bold italic leading-none tracking-tight", text, className)}>
      <span className="text-foreground">NEXO</span>
      <span className="text-gradient"> RUN</span>
    </span>
  );
}
