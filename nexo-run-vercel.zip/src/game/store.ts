import { create } from "zustand";
import type { GameMode, RunResult } from "./sim/types";

export type Phase = "loading" | "countdown" | "playing" | "paused" | "over";

interface HudState {
  time: number;
  noCoinTime: number;
  timerStopped: boolean;
  coins: number;
  score: number;
  speed: number;
}

interface GameUiStore {
  phase: Phase;
  mode: GameMode;
  hud: HudState;
  result: RunResult | null;
  localPosition: number;
  bestBefore: number;
  runId: number;
  setPhase: (p: Phase) => void;
  setHud: (h: HudState) => void;
  finish: (r: RunResult, localPosition: number, bestBefore: number) => void;
  restart: () => void;
}

const EMPTY_HUD: HudState = { time: 0, noCoinTime: 0, timerStopped: false, coins: 0, score: 0, speed: 0 };

/** UI-facing game state only. Per-frame simulation state lives in refs, not here. */
export const useGameUi = create<GameUiStore>()((set) => ({
  phase: "loading",
  mode: "nocoin",
  hud: EMPTY_HUD,
  result: null,
  localPosition: 0,
  bestBefore: 0,
  runId: 0,
  setPhase: (phase) => set({ phase }),
  setHud: (hud) => set({ hud }),
  finish: (result, localPosition, bestBefore) => set({ result, localPosition, bestBefore, phase: "over" }),
  restart: () => set((s) => ({ runId: s.runId + 1, phase: "countdown", result: null, hud: EMPTY_HUD })),
}));
