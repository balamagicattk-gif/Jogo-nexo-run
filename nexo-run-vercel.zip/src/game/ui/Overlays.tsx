import { Link } from "@tanstack/react-router";
import { Coins, Home, Play, RotateCcw, Route as RouteIcon, Timer, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { formatTime, rankValue } from "../localRanking";
import { useSettings } from "../settings";
import { useGameUi } from "../store";

export function Countdown({ value }: { value: number }) {
  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
      <div key={value} className="hud-glow animate-count font-display text-8xl font-bold text-primary">
        {value > 0 ? value : "VAI!"}
      </div>
    </div>
  );
}

export function LoadingOverlay() {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-background">
      <div className="size-12 animate-spin rounded-full border-2 border-border border-t-primary" />
      <p className="font-display text-sm uppercase tracking-[0.3em] text-muted-foreground">Carregando pista</p>
    </div>
  );
}

export function PauseOverlay({ onResume, onRestart }: { onResume: () => void; onRestart: () => void }) {
  const st = useSettings();
  return (
    <div className="scrim absolute inset-0 z-30 flex items-center justify-center p-4">
      <div className="panel w-full max-w-sm animate-rise p-6">
        <h2 className="text-center text-3xl font-bold">Pausado</h2>
        <div className="mt-6 flex flex-col gap-3">
          <Button variant="hero" size="xl" onClick={onResume} autoFocus>
            <Play /> Continuar
          </Button>
          <Button variant="panel" size="lg" onClick={onRestart}>
            <RotateCcw /> Reiniciar corrida
          </Button>
          <Button variant="panel" size="lg" asChild>
            <Link to="/">
              <Home /> Menu
            </Link>
          </Button>
        </div>
        <div className="mt-6 space-y-3 border-t border-border pt-5">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Volume geral</span>
            <span className="tabular-nums">{Math.round(st.master * 100)}%</span>
          </div>
          <Slider value={[st.master]} min={0} max={1} step={0.05} onValueChange={([v]) => st.set({ master: v ?? 0 })} aria-label="Volume geral" />
        </div>
      </div>
    </div>
  );
}

export function GameOverOverlay({ onAgain }: { onAgain: () => void }) {
  const { result, localPosition, bestBefore } = useGameUi();
  if (!result) return null;
  const value = rankValue(result);
  const isRecord = value > bestBefore;
  const nocoin = result.mode === "nocoin";
  return (
    <div className="scrim absolute inset-0 z-30 flex items-center justify-center overflow-y-auto p-4">
      <div className="panel w-full max-w-md animate-rise p-6 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          {nocoin ? "Modo No Coin" : "Modo Pontuação"}
        </p>
        <h2 className="mt-2 text-3xl font-bold">{isRecord ? "Novo recorde!" : "Fim de corrida"}</h2>
        <div className="mt-4 font-display text-6xl font-bold text-primary hud-glow tabular-nums">
          {nocoin ? `${formatTime(value)}s` : value.toLocaleString("pt-BR")}
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          {nocoin ? "tempo sem pegar moedas" : "pontos"}
          {bestBefore > 0 && ` · recorde anterior ${nocoin ? formatTime(bestBefore) + "s" : bestBefore.toLocaleString("pt-BR")}`}
        </p>
        <div className="mt-6 grid grid-cols-3 gap-2 text-left">
          <Stat icon={<RouteIcon className="size-4" />} label="Distância" value={`${Math.round(result.distance)} m`} />
          <Stat icon={<Coins className="size-4 text-gold" />} label="Moedas" value={String(result.coins)} />
          <Stat icon={<Timer className="size-4" />} label="Duração" value={`${formatTime(result.time)}s`} />
        </div>
        {localPosition > 0 && (
          <p className="mt-4 flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <Trophy className="size-4 text-gold" /> {localPosition}º lugar no ranking deste aparelho
          </p>
        )}
        <div className="mt-6 flex flex-col gap-3">
          <Button variant="hero" size="xl" onClick={onAgain} autoFocus>
            <RotateCcw /> Jogar de novo
          </Button>
          <Button variant="panel" size="lg" asChild>
            <Link to="/">
              <Home /> Menu
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface p-3">
      <div className="flex items-center gap-1.5 text-[11px] uppercase tracking-wider text-muted-foreground">
        {icon}
        {label}
      </div>
      <div className="mt-1 font-display text-lg font-bold tabular-nums">{value}</div>
    </div>
  );
}
