import { ChevronDown, ChevronLeft, ChevronRight, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Action } from "../sim/types";

/** Optional on-screen buttons (Settings → Controles). Swipes work regardless. */
export function TouchControls({ onAction }: { onAction: (a: Action) => void }) {
  const btn = (a: Action, label: string, icon: React.ReactNode) => (
    <Button
      variant="hud"
      size="icon-lg"
      aria-label={label}
      className="h-16 w-16 rounded-2xl"
      onPointerDown={(e) => {
        e.stopPropagation();
        onAction(a);
      }}
    >
      {icon}
    </Button>
  );
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between px-4 pb-[max(env(safe-area-inset-bottom),5rem)]">
      <div className="pointer-events-auto flex gap-3">
        {btn("left", "Esquerda", <ChevronLeft />)}
        {btn("right", "Direita", <ChevronRight />)}
      </div>
      <div className="pointer-events-auto flex flex-col gap-3">
        {btn("jump", "Pular", <ChevronUp />)}
        {btn("slide", "Deslizar", <ChevronDown />)}
      </div>
    </div>
  );
}
