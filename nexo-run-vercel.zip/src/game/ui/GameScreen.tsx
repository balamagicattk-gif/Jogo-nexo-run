import { lazy, Suspense, useCallback, useEffect, useRef, useState } from "react";
import { mixer } from "../audio/mixer";
import { getCharacter } from "../content/characters";
import { getMap } from "../content/maps";
import { keyToAction, swipeToAction } from "../input";
import { addLocalRun, rankValue, readLocalRanking } from "../localRanking";
import { createRuntime, type Runtime } from "../runtime";
import { useSettings } from "../settings";
import { toResult } from "../sim/engine";
import type { Action, GameEvent, GameMode } from "../sim/types";
import { useGameUi } from "../store";
import { Hud } from "./Hud";
import { Countdown, GameOverOverlay, LoadingOverlay, PauseOverlay } from "./Overlays";
import { TouchControls } from "./TouchControls";

const GameCanvas = lazy(() => import("../scene/GameCanvas"));

export function GameScreen({ mode }: { mode: GameMode }) {
  const settings = useSettings();
  const map = getMap(settings.mapId);
  const character = getCharacter(settings.characterId);
  const rt = useRef<Runtime>(createRuntime(mode));
  const wrap = useRef<HTMLDivElement>(null);
  const fpsRef = useRef<HTMLSpanElement>(null);
  const phase = useGameUi((s) => s.phase);
  const runId = useGameUi((s) => s.runId);
  const [count, setCount] = useState(3);
  const ready = useRef(false);

  // Fresh UI state on mount.
  useEffect(() => {
    useGameUi.setState({ phase: "loading", mode, result: null, runId: 0 });
    return () => {
      mixer.stopMusic();
    };
  }, [mode]);

  // Volumes follow settings.
  useEffect(() => {
    mixer.setVolumes(settings.master, settings.music, settings.sfx, settings.muted);
  }, [settings.master, settings.music, settings.sfx, settings.muted]);

  // New run on restart.
  useEffect(() => {
    if (runId === 0) return;
    rt.current = Object.assign(createRuntime(mode), { runnerReady: true });
  }, [runId, mode]);

  // Countdown → playing.
  useEffect(() => {
    if (phase !== "countdown") return;
    setCount(3);
    let n = 3;
    const id = window.setInterval(() => {
      n--;
      setCount(n);
      if (n < 0) {
        window.clearInterval(id);
        useGameUi.getState().setPhase("playing");
        mixer.play("start");
        mixer.startMusic();
      }
    }, 600);
    return () => window.clearInterval(id);
  }, [phase, runId]);

  const queue = useCallback((a: Action) => {
    mixer.unlock();
    if (useGameUi.getState().phase !== "playing") return;
    rt.current.queue.push(a);
  }, []);

  const togglePause = useCallback(() => {
    const ui = useGameUi.getState();
    if (ui.phase === "playing") {
      ui.setPhase("paused");
      mixer.stopMusic();
    } else if (ui.phase === "paused") {
      rt.current.acc = 0;
      ui.setPhase("playing");
      mixer.startMusic();
    }
  }, []);

  const restart = useCallback(() => {
    mixer.unlock();
    mixer.stopMusic();
    useGameUi.getState().restart();
  }, []);

  const fullscreen = useCallback(() => {
    const el = document.documentElement;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.().catch(() => {});
  }, []);

  // Keyboard
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.code === "Escape" || e.code === "KeyP") {
        togglePause();
        return;
      }
      const a = keyToAction(e.code);
      if (!a) return;
      e.preventDefault();
      if (e.repeat) return;
      queue(a);
    };
    window.addEventListener("keydown", down);
    return () => window.removeEventListener("keydown", down);
  }, [queue, togglePause]);

  // Swipes: fire as soon as the finger passes the threshold, one action per touch.
  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    let sx = 0;
    let sy = 0;
    let active = false;
    const down = (e: PointerEvent) => {
      mixer.unlock();
      sx = e.clientX;
      sy = e.clientY;
      active = true;
    };
    const move = (e: PointerEvent) => {
      if (!active) return;
      const a = swipeToAction(e.clientX - sx, e.clientY - sy, 24);
      if (a) {
        active = false;
        queue(a);
      }
    };
    const up = () => {
      active = false;
    };
    el.addEventListener("pointerdown", down);
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    return () => {
      el.removeEventListener("pointerdown", down);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
  }, [queue]);

  // Auto-pause when the tab is hidden.
  useEffect(() => {
    const vis = () => {
      if (document.hidden && useGameUi.getState().phase === "playing") togglePause();
    };
    document.addEventListener("visibilitychange", vis);
    return () => document.removeEventListener("visibilitychange", vis);
  }, [togglePause]);

  const onEvents = useCallback((events: GameEvent[]) => {
    for (const e of events) {
      if (e.type === "coin") mixer.play("coin", 1 + Math.min(0.3, (e.total % 10) * 0.03));
      else if (e.type === "jump") mixer.play("jump");
      else if (e.type === "slide") mixer.play("slide");
      else if (e.type === "lane") mixer.play("lane");
      else if (e.type === "timerStop") mixer.play("timer-stop");
      else if (e.type === "crash") {
        mixer.play("crash");
        mixer.stopMusic();
        if (navigator.vibrate) navigator.vibrate(120);
      }
    }
  }, []);

  const onCrashSettled = useCallback(() => {
    const r = toResult(rt.current.state);
    const best = readLocalRanking()[r.mode][0]?.value ?? 0;
    const s = useSettings.getState();
    const pos = addLocalRun(r, s.characterId, s.mapId);
    useGameUi.getState().finish(r, pos, best);
    void rankValue;
  }, []);

  const onReady = useCallback(() => {
    if (ready.current) return;
    ready.current = true;
    if (wrap.current) wrap.current.dataset["sceneReady"] = "1";
    useGameUi.getState().setPhase("countdown");
  }, []);

  return (
    <div ref={wrap} className="fixed inset-0 touch-none select-none overflow-hidden bg-background" style={{ touchAction: "none" }}>
      <Suspense fallback={null}>
        <GameCanvas
          rt={rt}
          map={map}
          characterUrl={character.modelUrl}
          coinColor={settings.coinColor}
          quality={settings.quality}
          fpsEl={fpsRef}
          onEvents={onEvents}
          onCrashSettled={onCrashSettled}
          onReady={onReady}
        />
      </Suspense>
      {phase === "loading" && <LoadingOverlay />}
      {phase !== "loading" && <Hud onPause={togglePause} onFullscreen={fullscreen} fpsRef={fpsRef} />}
      {phase === "countdown" && <Countdown value={count} />}
      {phase === "playing" && settings.showControls && <TouchControls onAction={queue} />}
      {phase === "paused" && <PauseOverlay onResume={togglePause} onRestart={restart} />}
      {phase === "over" && <GameOverOverlay onAgain={restart} />}
    </div>
  );
}
