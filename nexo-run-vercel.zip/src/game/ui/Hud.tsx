import { Coins, Gauge, Maximize, Pause, Timer, Trophy } from "lucide-react";
import type { CSSProperties, ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { formatTime } from "../localRanking";
import { useSettings, type HudSlot } from "../settings";
import { useGameUi } from "../store";
import { cn } from "@/lib/utils";

interface Props {
  onPause: () => void;
  onFullscreen: () => void;
  fpsRef: React.RefObject<HTMLSpanElement | null>;
}

export function Hud({ onPause, onFullscreen, fpsRef }: Props) {
  const hud = useGameUi((s) => s.hud);
  const mode = useGameUi((s) => s.mode);
  const st = useSettings();
  const slots: Record<HudSlot, ReactNode[]> = { left: [], center: [], right: [] };

  const timerValue = mode === "nocoin" ? hud.noCoinTime : hud.time;
  slots[st.timerSlot].push(
    <div key="timer" className={cn("flex flex-col items-center", hud.timerStopped && "opacity-60")}>
      <div className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
        <Timer className="size-3" />
        {mode === "nocoin" ? (hud.timerStopped ? "Cronômetro parado" : "Sem moedas") : "Tempo"}
      </div>
      <div className="hud-glow font-display text-5xl font-bold tabular-nums leading-none sm:text-6xl">
        {formatTime(timerValue)}
      </div>
      <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground tabular-nums">
        <Gauge className="size-3" /> {Math.round(hud.speed * 3.6)} km/h
      </div>
    </div>,
  );
  slots[st.coinsSlot].push(
    <div key="coins" className="hud-chip flex items-center gap-2 px-3 py-1.5 font-display text-lg font-bold tabular-nums">
      <Coins className="size-4" style={{ color: st.coinColor }} />
      {hud.coins}
    </div>,
  );
  if (mode === "score") {
    slots[st.scoreSlot].push(
      <div key="score" className="hud-chip flex items-center gap-2 px-3 py-1.5 font-display text-lg font-bold tabular-nums">
        <Trophy className="size-4 text-gold" />
        {hud.score.toLocaleString("pt-BR")}
      </div>,
    );
  }

  const style = { "--hud-accent": st.hudAccent, opacity: st.hudOpacity } as CSSProperties;

  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-10 pt-[max(env(safe-area-inset-top),0.75rem)]" style={style}>
      <div className="flex items-start justify-between gap-2 px-3">
        <div className="pointer-events-auto flex gap-2">
          <Button variant="hud" size="icon-lg" aria-label="Pausar" onClick={onPause}>
            <Pause />
          </Button>
          <Button variant="hud" size="icon-lg" aria-label="Tela cheia" onClick={onFullscreen} className="hidden sm:inline-flex">
            <Maximize />
          </Button>
        </div>
        {st.showFps && (
          <span ref={fpsRef} className="hud-chip px-2 py-1 font-mono text-xs text-success">
            -- FPS
          </span>
        )}
      </div>
      <div
        className="mt-2 grid grid-cols-3 items-start px-3"
        style={{ transform: `scale(${st.hudScale})`, transformOrigin: "top center" }}
      >
        <div className="flex flex-col items-start gap-2">{slots.left}</div>
        <div className="flex flex-col items-center gap-2">{slots.center}</div>
        <div className="flex flex-col items-end gap-2">{slots.right}</div>
      </div>
    </div>
  );
}
