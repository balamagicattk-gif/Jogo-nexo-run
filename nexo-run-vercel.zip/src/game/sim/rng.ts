/** Deterministic PRNG (mulberry32). Same seed → same run, so a run can be replayed on the server. */
export function createRng(seed: number) {
  let a = seed >>> 0;
  const next = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return {
    next,
    int: (min: number, max: number) => min + Math.floor(next() * (max - min + 1)),
    chance: (p: number) => next() < p,
    pick: <T,>(arr: readonly T[]) => arr[Math.floor(next() * arr.length)],
    get state() {
      return a;
    },
    set state(v: number) {
      a = v >>> 0;
    },
  };
}
export type Rng = ReturnType<typeof createRng>;
