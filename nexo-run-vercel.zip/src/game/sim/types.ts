export type GameMode = "nocoin" | "score";
export type Action = "left" | "right" | "jump" | "slide";
export type ObstacleKind = "train" | "low" | "high";

export interface Obstacle {
  id: number;
  kind: ObstacleKind;
  lane: number;
  /** World distance of the edge nearest the player. */
  z: number;
  /** Length along the track. */
  len: number;
  /** Train cars (trains only). */
  cars: number;
}

export interface Coin {
  id: number;
  lane: number;
  z: number;
  y: number;
  taken: boolean;
}

export type GameEvent =
  | { type: "coin"; total: number }
  | { type: "jump" }
  | { type: "slide" }
  | { type: "lane"; lane: number }
  | { type: "crash"; kind: ObstacleKind }
  | { type: "timerStop"; time: number };

export interface GeneratorState {
  nextRowZ: number;
  prevRowZ: number;
  safeLane: number;
  laneBusyUntil: [number, number, number];
  /** Safe lane per spawned row (used by tests, bots and debugging). */
  path: { z: number; lane: number }[];
}

export interface GameState {
  seed: number;
  mode: GameMode;
  step: number;
  time: number;
  dist: number;
  speed: number;
  lane: number;
  x: number;
  y: number;
  vy: number;
  grounded: boolean;
  /** Train currently supporting the runner; null while on the track or airborne. */
  onTrainId: number | null;
  slideT: number;
  alive: boolean;
  coins: number;
  /** No Coin mode: time survived before the first coin. Freezes at the first coin. */
  noCoinTime: number;
  timerStopped: boolean;
  score: number;
  crashKind: ObstacleKind | null;
  obstacles: Obstacle[];
  coinList: Coin[];
  gen: GeneratorState;
  rngState: number;
  nextId: number;
}

export interface RunResult {
  mode: GameMode;
  seed: number;
  steps: number;
  time: number;
  distance: number;
  coins: number;
  score: number;
  noCoinTime: number;
}

/** Input log entry: action applied right before step `s`. Enough to replay a run. */
export type InputLogEntry = [s: number, a: Action];
