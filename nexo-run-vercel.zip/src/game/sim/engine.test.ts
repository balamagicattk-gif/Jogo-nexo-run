import { describe, expect, it } from "vitest";
import { createGame, replayRun, stepGame, toResult } from "./engine";
import { CAR_LENGTH, COIN_SCORE, FIXED_DT, laneX, START_SPEED } from "./constants";
import type { Action, GameState, InputLogEntry } from "./types";
import { keyToAction, swipeToAction } from "../input";

const clearWorld = (s: GameState) => {
  s.obstacles = [];
  s.coinList = [];
  s.gen.nextRowZ = 1e9; // stop spawning
};
const run = (s: GameState, steps: number, first: Action[] = []) => {
  for (let i = 0; i < steps; i++) stepGame(s, i === 0 ? first : []);
};

describe("controls", () => {
  it("maps A/←, D/→, W/↑/Space, S/↓", () => {
    expect(keyToAction("KeyA")).toBe("left");
    expect(keyToAction("ArrowLeft")).toBe("left");
    expect(keyToAction("KeyD")).toBe("right");
    expect(keyToAction("ArrowRight")).toBe("right");
    expect(keyToAction("KeyW")).toBe("jump");
    expect(keyToAction("ArrowUp")).toBe("jump");
    expect(keyToAction("Space")).toBe("jump");
    expect(keyToAction("KeyS")).toBe("slide");
    expect(keyToAction("ArrowDown")).toBe("slide");
    expect(keyToAction("KeyQ")).toBeNull();
  });
  it("maps swipes left/right/up/down and ignores tiny moves", () => {
    expect(swipeToAction(-60, 5)).toBe("left");
    expect(swipeToAction(60, -5)).toBe("right");
    expect(swipeToAction(3, -60)).toBe("jump");
    expect(swipeToAction(3, 60)).toBe("slide");
    expect(swipeToAction(10, 10)).toBeNull();
  });
  it("changes lane and stays inside the 3 lanes", () => {
    const s = createGame(1, "score");
    clearWorld(s);
    run(s, 30, ["left"]);
    expect(s.lane).toBe(0);
    expect(s.x).toBeCloseTo(laneX(0), 1);
    stepGame(s, ["left"]);
    expect(s.lane).toBe(0);
    stepGame(s, ["right", "right", "right"]);
    expect(s.lane).toBe(2);
  });
  it("jumps above 2 m and lands again", () => {
    const s = createGame(1, "score");
    clearWorld(s);
    let maxY = 0;
    stepGame(s, ["jump"]);
    for (let i = 0; i < 60; i++) {
      stepGame(s);
      maxY = Math.max(maxY, s.y);
    }
    expect(maxY).toBeGreaterThan(2);
    expect(s.grounded).toBe(true);
  });
  it("slide in the air slams the runner down fast", () => {
    const s = createGame(1, "score");
    clearWorld(s);
    run(s, 10, ["jump"]);
    const airborne = s.y;
    run(s, 8, ["slide"]);
    expect(airborne).toBeGreaterThan(1);
    expect(s.y).toBe(0);
    expect(s.slideT).toBeGreaterThan(0);
  });
});

describe("speed", () => {
  it("starts at the start speed and increases over time", () => {
    const s = createGame(1, "score");
    clearWorld(s);
    expect(s.speed).toBe(START_SPEED);
    run(s, 600);
    expect(s.speed).toBeGreaterThan(START_SPEED + 2);
  });
});

describe("collisions", () => {
  const withObstacle = (kind: "train" | "low" | "high") => {
    const s = createGame(1, "score");
    clearWorld(s);
    s.obstacles.push({ id: 999, kind, lane: 1, z: s.dist + 6, len: kind === "train" ? CAR_LENGTH * 2 : 0.35, cars: 2 });
    return s;
  };
  it("can jump onto a train roof and survive while running over it", () => {
    const s = withObstacle("train");
    s.obstacles[0]!.len = 8 * CAR_LENGTH;
    s.obstacles[0]!.cars = 8;
    run(s, 80, ["jump"]);
    expect(s.alive).toBe(true);
    expect(s.crashKind).toBeNull();
  });
  it("dodging a train by changing lane survives", () => {
    const s = withObstacle("train");
    run(s, 120, ["left"]);
    expect(s.alive).toBe(true);
  });
  it("a low barrier can be passed by sliding or jumping over it", () => {
    const a = withObstacle("low");
    run(a, 120);
    expect(a.alive).toBe(false);
    const sliding = withObstacle("low");
    for (let i = 0; i < 120; i++) stepGame(sliding, i === 8 ? ["slide"] : []);
    expect(sliding.alive).toBe(true);
    const jumping = withObstacle("low");
    for (let i = 0; i < 120; i++) stepGame(jumping, i === 8 ? ["jump"] : []);
    expect(jumping.alive).toBe(true);
  });
  it("a high barrier can be passed by sliding or jumping completely over it", () => {
    const a = withObstacle("high");
    run(a, 120);
    expect(a.alive).toBe(false);
    const sliding = withObstacle("high");
    for (let i = 0; i < 120; i++) stepGame(sliding, i === 10 ? ["slide"] : []);
    expect(sliding.alive).toBe(true);
    const jumping = withObstacle("high");
    for (let i = 0; i < 120; i++) stepGame(jumping, i === 8 ? ["jump"] : []);
    expect(jumping.alive).toBe(true);
  });
});

describe("coins and modes", () => {
  it("score mode rewards distance and coins", () => {
    const s = createGame(1, "score");
    clearWorld(s);
    s.coinList.push({ id: 1, lane: 1, z: s.dist + 3, y: 1, taken: false });
    run(s, 60);
    expect(s.coins).toBe(1);
    expect(s.score).toBe(Math.floor(s.dist) + COIN_SCORE);
  });
  it("No Coin mode stops the timer at the first coin", () => {
    const s = createGame(1, "nocoin");
    clearWorld(s);
    s.coinList.push({ id: 1, lane: 1, z: s.dist + 13, y: 1, taken: false });
    run(s, 120);
    expect(s.timerStopped).toBe(true);
    const frozen = s.noCoinTime;
    expect(frozen).toBeGreaterThan(0.8);
    expect(frozen).toBeLessThan(1.2);
    run(s, 60);
    expect(s.noCoinTime).toBe(frozen);
    expect(s.time).toBeGreaterThan(frozen + 0.9);
  });
  it("No Coin timer keeps running while no coin is taken", () => {
    const s = createGame(1, "nocoin");
    clearWorld(s);
    run(s, 180);
    expect(s.noCoinTime).toBeCloseTo(180 * FIXED_DT, 5);
  });
});

describe("generator", () => {
  it("always leaves a survivable, coin-free path (a path-following bot survives 3 minutes)", () => {
    for (const mode of ["score", "nocoin"] as const) {
      for (let seed = 1; seed <= 6; seed++) {
        const s = createGame(seed * 7919, mode);
        let steps = 0;
        while (s.alive && steps < 60 * 180) {
          const acts: Action[] = [];
          const row = s.gen.path.find((p) => p.z > s.dist - 0.4);
          const target = row ? row.lane : s.lane;
          if (target < s.lane) acts.push("left");
          if (target > s.lane) acts.push("right");
          const ahead = s.obstacles.find((o) => o.lane === s.lane && o.z > s.dist && o.z - s.dist < s.speed * 0.32);
          if (ahead?.kind === "low" && s.grounded) acts.push("jump");
          if (ahead?.kind === "high" && s.slideT <= 0.05) acts.push("slide");
          stepGame(s, acts);
          steps++;
        }
        expect({ mode, seed, alive: s.alive, crash: s.crashKind, coinsInNoCoin: mode === "nocoin" ? s.coins : 0 }).toEqual({ mode, seed, alive: true, crash: null, coinsInNoCoin: 0 });
      }
    }
  });
  it("is deterministic: replaying seed + inputs gives the same result", () => {
    const inputs: InputLogEntry[] = [
      [30, "left"],
      [90, "right"],
      [140, "jump"],
      [200, "right"],
      [260, "slide"],
    ];
    const a = replayRun(42, "score", inputs, 60 * 60);
    const b = replayRun(42, "score", inputs, 60 * 60);
    expect(a).toEqual(b);
    expect(a.steps).toBeGreaterThan(0);
  });
});

void toResult;
