import {
  ACCEL,
  COIN_RADIUS,
  COIN_SCORE,
  DESPAWN_BEHIND,
  FIXED_DT,
  GRAVITY,
  HIGH_BARRIER_BOTTOM,
  JUMP_VELOCITY,
  LANE_SMOOTH,
  LOW_BARRIER_TOP,
  MAX_SPEED,
  PLAYER_HALF_DEPTH,
  PLAYER_HALF_WIDTH,
  PLAYER_HEIGHT,
  PLAYER_SLIDE_HEIGHT,
  SLAM_VELOCITY,
  SLIDE_TIME,
  START_SPEED,
  TRAIN_HALF_WIDTH,
  TRAIN_HEIGHT,
  BARRIER_HALF_WIDTH,
  laneX,
} from "./constants";
import { generateAhead } from "./generator";
import { createRng } from "./rng";
import type { Action, GameEvent, GameMode, GameState, InputLogEntry, RunResult } from "./types";

export function createGame(seed: number, mode: GameMode): GameState {
  const s: GameState = {
    seed,
    mode,
    step: 0,
    time: 0,
    dist: 0,
    speed: START_SPEED,
    lane: 1,
    x: 0,
    y: 0,
    vy: 0,
    grounded: true,
    onTrainId: null,
    slideT: 0,
    alive: true,
    coins: 0,
    noCoinTime: 0,
    timerStopped: false,
    score: 0,
    crashKind: null,
    obstacles: [],
    coinList: [],
    gen: { nextRowZ: 40, prevRowZ: 20, safeLane: 1, laneBusyUntil: [0, 0, 0], path: [] },
    rngState: seed >>> 0,
    nextId: 1,
  };
  const rng = createRng(0);
  rng.state = s.rngState;
  generateAhead(s, rng);
  s.rngState = rng.state;
  return s;
}

export function applyAction(s: GameState, a: Action, events: GameEvent[]) {
  if (!s.alive) return;
  switch (a) {
    case "left":
      if (s.lane > 0) {
        s.lane--;
        events.push({ type: "lane", lane: s.lane });
      }
      break;
    case "right":
      if (s.lane < 2) {
        s.lane++;
        events.push({ type: "lane", lane: s.lane });
      }
      break;
    case "jump":
      if (s.grounded) {
        s.vy = JUMP_VELOCITY;
        s.grounded = false;
        s.slideT = 0;
        events.push({ type: "jump" });
      }
      break;
    case "slide":
      if (!s.grounded) s.vy = Math.min(s.vy, SLAM_VELOCITY);
      s.slideT = SLIDE_TIME;
      events.push({ type: "slide" });
      break;
  }
}

/** Advances the simulation by one fixed step. Pure apart from mutating `s`. */
export function stepGame(s: GameState, actions: readonly Action[] = []): GameEvent[] {
  const events: GameEvent[] = [];
  if (!s.alive) return events;
  for (const a of actions) applyAction(s, a, events);

  const dt = FIXED_DT;
  s.step++;
  s.time += dt;
  s.speed = Math.min(MAX_SPEED, s.speed + ACCEL * dt);
  s.dist += s.speed * dt;

  // Lateral
  const tx = laneX(s.lane);
  s.x += (tx - s.x) * (1 - Math.exp(-LANE_SMOOTH * dt));
  if (Math.abs(tx - s.x) < 0.001) s.x = tx;

  // Vertical movement and train-roof landings. The runner can jump from the track
  // onto a train, run along its roof, and jump again from the roof.
  const trainAtPlayer = s.obstacles.find((o) =>
    o.kind === "train" &&
    Math.abs(s.x - laneX(o.lane)) < TRAIN_HALF_WIDTH + PLAYER_HALF_WIDTH - 0.15 &&
    s.dist + PLAYER_HALF_DEPTH >= o.z &&
    s.dist - PLAYER_HALF_DEPTH <= o.z + o.len,
  );
  if (s.grounded && s.onTrainId !== null) {
    const currentTrain = s.obstacles.find((o) => o.id === s.onTrainId && o.kind === "train");
    if (!currentTrain || s.dist + PLAYER_HALF_DEPTH >= currentTrain.z + currentTrain.len) {
      s.onTrainId = null;
      s.grounded = false;
      s.vy = 0;
    } else {
      s.y = TRAIN_HEIGHT;
    }
  }
  if (!s.grounded) {
    const previousY = s.y;
    s.vy -= GRAVITY * dt;
    s.y += s.vy * dt;
    if (s.vy <= 0 && trainAtPlayer && previousY >= TRAIN_HEIGHT && s.y <= TRAIN_HEIGHT) {
      s.y = TRAIN_HEIGHT;
      s.vy = 0;
      s.grounded = true;
      s.onTrainId = trainAtPlayer.id;
    } else if (s.y <= 0) {
      s.y = 0;
      s.vy = 0;
      s.grounded = true;
      s.onTrainId = null;
    }
  }
  // Slide timer only counts down on the ground (a slam keeps the slide for landing).
  if (s.grounded && s.slideT > 0) s.slideT = Math.max(0, s.slideT - dt);

  if (!s.timerStopped) s.noCoinTime = s.time;

  // Collisions
  const sliding = s.slideT > 0 && s.grounded;
  const top = s.y + (sliding ? PLAYER_SLIDE_HEIGHT : PLAYER_HEIGHT);
  const pz0 = s.dist - PLAYER_HALF_DEPTH;
  const pz1 = s.dist + PLAYER_HALF_DEPTH;
  for (const o of s.obstacles) {
    if (o.z > pz1 || o.z + o.len < pz0) continue;
    const half = o.kind === "train" ? TRAIN_HALF_WIDTH : BARRIER_HALF_WIDTH;
    if (Math.abs(s.x - laneX(o.lane)) >= half + PLAYER_HALF_WIDTH - 0.15) continue;
    let hit = false;
    if (o.kind === "train") {
      // A train is safe when the runner is on its roof or has cleared the roof
      // while jumping. Hitting its side/front at a lower height remains fatal.
      const onThisTrain = s.onTrainId === o.id;
      hit = !onThisTrain && s.y < TRAIN_HEIGHT - 0.05;
    } else if (o.kind === "low") {
      // Low barrier: either crouch under it or jump over its top.
      hit = !(sliding || s.y >= LOW_BARRIER_TOP);
    } else {
      // Overhead barrier: either slide under it or jump completely above it.
      const highBarrierTop = HIGH_BARRIER_BOTTOM + 0.55;
      hit = !(sliding || s.y >= highBarrierTop);
    }
    if (hit) {
      s.alive = false;
      s.crashKind = o.kind;
      events.push({ type: "crash", kind: o.kind });
      break;
    }
  }

  // Coins
  if (s.alive) {
    const py = s.y + 0.8;
    for (const c of s.coinList) {
      if (c.taken) continue;
      if (Math.abs(c.z - s.dist) > COIN_RADIUS) continue;
      if (Math.abs(laneX(c.lane) - s.x) > COIN_RADIUS) continue;
      if (Math.abs(c.y - py) > 1.2) continue;
      c.taken = true;
      s.coins++;
      events.push({ type: "coin", total: s.coins });
      if (s.mode === "nocoin" && !s.timerStopped) {
        s.timerStopped = true;
        events.push({ type: "timerStop", time: s.noCoinTime });
      }
    }
  }

  s.score = computeScore(s.mode, s.dist, s.coins);

  // Despawn + spawn
  if (s.step % 30 === 0) {
    const cut = s.dist - DESPAWN_BEHIND;
    s.obstacles = s.obstacles.filter((o) => o.z + o.len > cut);
    s.coinList = s.coinList.filter((c) => c.z > cut);
    s.gen.path = s.gen.path.filter((p) => p.z > cut);
  }
  const rng = createRng(0);
  rng.state = s.rngState;
  generateAhead(s, rng);
  s.rngState = rng.state;

  return events;
}

export function computeScore(mode: GameMode, dist: number, coins: number) {
  return mode === "score" ? Math.floor(dist) + coins * COIN_SCORE : Math.floor(dist);
}

export function toResult(s: GameState): RunResult {
  return {
    mode: s.mode,
    seed: s.seed,
    steps: s.step,
    time: s.time,
    distance: s.dist,
    coins: s.coins,
    score: s.score,
    noCoinTime: s.noCoinTime,
  };
}

/**
 * Replays a run from its seed and input log. The server uses this to recompute
 * the result instead of trusting values sent by the browser.
 */
export function replayRun(seed: number, mode: GameMode, inputs: readonly InputLogEntry[], maxSteps: number) {
  const s = createGame(seed, mode);
  let i = 0;
  while (s.alive && s.step < maxSteps) {
    const acts: Action[] = [];
    while (i < inputs.length && inputs[i]![0] <= s.step) acts.push(inputs[i++]![1]);
    stepGame(s, acts);
  }
  return toResult(s);
}
