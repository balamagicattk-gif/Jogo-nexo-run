import {
  BARRIER_DEPTH,
  CAR_LENGTH,
  COIN_SPACING,
  SPAWN_AHEAD,
  WARMUP_DISTANCE,
} from "./constants";
import type { Rng } from "./rng";
import type { GameState } from "./types";

/** Row spacing grows with speed so the player keeps ~0.85 s of reaction time. */
export function rowGap(speed: number) {
  return Math.min(26, Math.max(12, speed * 0.85));
}

/** Difficulty 0..1 by distance. */
export function difficulty(dist: number) {
  return Math.min(1, dist / 2500);
}

/**
 * Spawns obstacle rows ahead of the player.
 * Invariant: a "safe lane" path exists that changes at most one lane per row and is never
 * covered by a train, so every run stays survivable.
 */
export function generateAhead(s: GameState, rng: Rng) {
  const g = s.gen;
  while (g.nextRowZ < s.dist + SPAWN_AHEAD) {
    const z = g.nextRowZ;
    const d = difficulty(z);

    // Choose next safe lane among adjacent lanes clear since the previous row.
    const candidates = [g.safeLane - 1, g.safeLane, g.safeLane + 1].filter(
      (l) => l >= 0 && l <= 2 && (g.laneBusyUntil[l] ?? 0) <= g.prevRowZ + 0.5,
    );
    let safe = g.safeLane;
    if (candidates.length > 0 && !rng.chance(0.5)) safe = rng.pick(candidates) ?? g.safeLane;
    if (!candidates.includes(safe)) safe = candidates[0] ?? g.safeLane;

    const pTrain = 0.25 + 0.25 * d;
    const pLow = 0.18 + 0.1 * d;
    const pHigh = 0.12 + 0.1 * d;

    for (let lane = 0; lane < 3; lane++) {
      if ((g.laneBusyUntil[lane] ?? 0) > z) continue; // a train still occupies this lane
      if (lane === safe) {
        const r = rng.next();
        if (d > 0.05 && r < 0.18 + 0.12 * d) addObstacle(s, "low", lane, z, BARRIER_DEPTH, 0);
        else if (d > 0.1 && r < 0.3 + 0.15 * d) addObstacle(s, "high", lane, z, BARRIER_DEPTH, 0);
        continue;
      }
      const r = rng.next();
      if (r < pTrain) {
        const cars = rng.int(2, 3 + Math.round(2 * d));
        const len = cars * CAR_LENGTH;
        addObstacle(s, "train", lane, z, len, cars);
        g.laneBusyUntil[lane] = z + len;
      } else if (r < pTrain + pLow) {
        addObstacle(s, "low", lane, z, BARRIER_DEPTH, 0);
      } else if (r < pTrain + pLow + pHigh) {
        addObstacle(s, "high", lane, z, BARRIER_DEPTH, 0);
      }
    }

    // Coins between the previous row and this one.
    const from = g.prevRowZ + 2;
    const to = z - 2;
    if (to > from) {
      if (s.mode === "score") {
        // Reward line along the safe path.
        if (rng.chance(0.75)) addCoinLine(s, safe, from, to);
      } else {
        // No Coin: coins are hazards, placed only off the safe path.
        const offPath = [0, 1, 2].filter((l) => l !== safe && l !== g.safeLane);
        for (const l of offPath) if (rng.chance(0.35 + 0.4 * d)) addCoinLine(s, l, from, to);
      }
    }

    g.safeLane = safe;
    g.path.push({ z, lane: safe });
    g.prevRowZ = z;
    g.nextRowZ = z + rowGap(s.speed);
  }
}

function addObstacle(s: GameState, kind: "train" | "low" | "high", lane: number, z: number, len: number, cars: number) {
  if (z < WARMUP_DISTANCE) return;
  s.obstacles.push({ id: s.nextId++, kind, lane, z, len, cars });
}

function addCoinLine(s: GameState, lane: number, from: number, to: number) {
  for (let z = from; z <= to; z += COIN_SPACING) {
    if (z < 25) continue;
    // Never place coins inside a train.
    const blocked = s.obstacles.some(
      (o) => o.kind === "train" && o.lane === lane && z >= o.z - 1 && z <= o.z + o.len + 1,
    );
    if (blocked) continue;
    s.coinList.push({ id: s.nextId++, lane, z, y: 1, taken: false });
  }
}
