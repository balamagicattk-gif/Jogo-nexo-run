/** Game-feel constants. All tuning lives here so it can be changed in one place. */
export const FIXED_DT = 1 / 60;
export const LANE_WIDTH = 2.2;
export const LANE_COUNT = 3;

export const START_SPEED = 13; // m/s
export const MAX_SPEED = 32; // m/s
export const ACCEL = 0.22; // m/s gained per second

export const GRAVITY = 42;
export const JUMP_VELOCITY = 16; // apex ≈ 3.05 m: enough height to land on train roofs
export const SLAM_VELOCITY = -30;
export const SLIDE_TIME = 0.62;
export const LANE_SMOOTH = 18; // exponential lane-change rate

export const PLAYER_HALF_DEPTH = 0.35;
export const PLAYER_HALF_WIDTH = 0.38;
export const PLAYER_HEIGHT = 1.7;
export const PLAYER_SLIDE_HEIGHT = 0.8;

export const CAR_LENGTH = 2.6;
export const TRAIN_HALF_WIDTH = 0.9;
export const TRAIN_HEIGHT = 2.6;
export const BARRIER_DEPTH = 0.35;
export const BARRIER_HALF_WIDTH = 0.95;
export const LOW_BARRIER_TOP = 0.95;
export const HIGH_BARRIER_BOTTOM = 1.2;

export const COIN_RADIUS = 0.9;
export const COIN_SPACING = 2.2;
export const COIN_SCORE = 10;

export const WARMUP_DISTANCE = 60;
export const SPAWN_AHEAD = 140;
export const DESPAWN_BEHIND = 15;

export const laneX = (lane: number) => (lane - 1) * LANE_WIDTH;
