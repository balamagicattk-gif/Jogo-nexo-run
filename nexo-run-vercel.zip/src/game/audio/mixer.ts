/**
 * One AudioContext with sfx and music buses → master → limiter.
 * Created on the first user gesture (browsers block audio before that).
 */
type SoundName = "coin" | "jump" | "slide" | "lane" | "crash" | "timer-stop" | "start";
const SOUNDS: SoundName[] = ["coin", "jump", "slide", "lane", "crash", "timer-stop", "start"];
const GAIN: Record<SoundName, number> = {
  coin: 0.55,
  jump: 0.45,
  slide: 0.45,
  lane: 0.2,
  crash: 0.9,
  "timer-stop": 0.6,
  start: 0.5,
};

class Mixer {
  ctx: AudioContext | null = null;
  master!: GainNode;
  sfx!: GainNode;
  music!: GainNode;
  buffers = new Map<SoundName, AudioBuffer>();
  private musicTimer: number | null = null;
  private nextBeat = 0;
  private beat = 0;

  unlock() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    this.ctx = ctx;
    const limiter = ctx.createDynamicsCompressor();
    limiter.threshold.value = -6;
    limiter.ratio.value = 12;
    this.master = ctx.createGain();
    this.sfx = ctx.createGain();
    this.music = ctx.createGain();
    this.sfx.connect(this.master);
    this.music.connect(this.master);
    this.master.connect(limiter).connect(ctx.destination);
    for (const n of SOUNDS) {
      fetch(`/audio/${n}.mp3`)
        .then((r) => r.arrayBuffer())
        .then((b) => ctx.decodeAudioData(b))
        .then((buf) => this.buffers.set(n, buf))
        .catch(() => {});
    }
  }

  setVolumes(master: number, music: number, sfx: number, muted: boolean) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(muted ? 0 : master, t, 0.02);
    this.music.gain.setTargetAtTime(music * 0.35, t, 0.02);
    this.sfx.gain.setTargetAtTime(sfx, t, 0.02);
  }

  play(name: SoundName, rate = 1) {
    const ctx = this.ctx;
    const buf = this.buffers.get(name);
    if (!ctx || !buf) return;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = rate;
    const g = ctx.createGain();
    g.gain.value = GAIN[name];
    src.connect(g).connect(this.sfx);
    src.start();
  }

  /** Lightweight synthesized loop (bass + hats), scheduled ahead with the audio clock. */
  startMusic() {
    if (!this.ctx || this.musicTimer !== null) return;
    this.nextBeat = this.ctx.currentTime + 0.1;
    this.beat = 0;
    const bpm = 112;
    const step = 60 / bpm / 2;
    const bass = [45, 45, 52, 45, 48, 48, 43, 47];
    const tick = () => {
      const ctx = this.ctx!;
      while (this.nextBeat < ctx.currentTime + 0.25) {
        const t = this.nextBeat;
        const i = this.beat % 16;
        if (i % 2 === 0) this.note(bass[(this.beat >> 1) % bass.length] ?? 45, t, step * 1.8, "sawtooth", 0.18);
        this.hat(t, i % 4 === 2 ? 0.12 : 0.05);
        if (i % 8 === 0) this.kick(t);
        this.nextBeat += step;
        this.beat++;
      }
    };
    this.musicTimer = window.setInterval(tick, 50);
    tick();
  }

  stopMusic() {
    if (this.musicTimer !== null) window.clearInterval(this.musicTimer);
    this.musicTimer = null;
  }

  private note(midi: number, t: number, dur: number, type: OscillatorType, vol: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    const f = ctx.createBiquadFilter();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.value = 440 * Math.pow(2, (midi - 69) / 12);
    f.type = "lowpass";
    f.frequency.value = 600;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(f).connect(g).connect(this.music);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  private hat(t: number, vol: number) {
    const ctx = this.ctx!;
    const len = Math.floor(ctx.sampleRate * 0.04);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = "highpass";
    f.frequency.value = 7000;
    const g = ctx.createGain();
    g.gain.value = vol;
    src.connect(f).connect(g).connect(this.music);
    src.start(t);
  }

  private kick(t: number) {
    const ctx = this.ctx!;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.frequency.setValueAtTime(140, t);
    o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
    g.gain.setValueAtTime(0.5, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
    o.connect(g).connect(this.music);
    o.start(t);
    o.stop(t + 0.25);
  }
}

export const mixer = new Mixer();
export type { SoundName };
