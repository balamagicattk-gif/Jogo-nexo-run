import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Quality = "low" | "medium" | "high";
export type HudSlot = "left" | "center" | "right";

/** Coin and HUD accent colors players may choose from. */
export const ALLOWED_COLORS = ["#22d3ee", "#38bdf8", "#facc15", "#f472b6", "#4ade80", "#ffffff"] as const;

export interface Settings {
  master: number;
  music: number;
  sfx: number;
  muted: boolean;
  quality: Quality;
  showFps: boolean;
  showControls: boolean;
  hudScale: number;
  hudOpacity: number;
  timerSlot: HudSlot;
  coinsSlot: HudSlot;
  scoreSlot: HudSlot;
  coinColor: string;
  hudAccent: string;
  characterId: string;
  mapId: string;
}

export const DEFAULT_SETTINGS: Settings = {
  master: 0.8,
  music: 0.5,
  sfx: 0.8,
  muted: false,
  quality: "medium",
  showFps: false,
  showControls: false,
  hudScale: 1,
  hudOpacity: 1,
  timerSlot: "center",
  coinsSlot: "right",
  scoreSlot: "left",
  coinColor: "#facc15",
  hudAccent: "#22d3ee",
  characterId: "kai",
  mapId: "distrito",
};

interface SettingsStore extends Settings {
  set: (patch: Partial<Settings>) => void;
  reset: () => void;
}

/**
 * Player preferences, kept on this device. Read only on client-rendered screens
 * (or after hydration) to avoid server/client mismatches.
 */
export const useSettings = create<SettingsStore>()(
  persist(
    (set) => ({
      ...DEFAULT_SETTINGS,
      set: (patch) => set(patch),
      reset: () => set(DEFAULT_SETTINGS),
    }),
    { name: "nexo-settings-v1", skipHydration: true },
  ),
);
