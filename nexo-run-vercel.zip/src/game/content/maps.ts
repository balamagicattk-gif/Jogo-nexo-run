export interface MapDef {
  id: string;
  name: string;
  description: string;
  free: boolean;
  sky: string;
  fog: [near: number, far: number];
  ground: string;
  gravel: string;
  buildings: string[];
  windows: string;
  accent: string;
  hemiSky: string;
  hemiGround: string;
  hemiIntensity: number;
  sun: string;
  sunIntensity: number;
  trainTint: string;
}

/** Starting maps. Admin management arrives with the database phase. */
export const MAPS: MapDef[] = [
  {
    id: "distrito",
    name: "Distrito Nexo",
    description: "Pátio ferroviário noturno com torres iluminadas em ciano.",
    free: true,
    sky: "#0b1220",
    fog: [30, 150],
    ground: "#1a1f29",
    gravel: "#2b3240",
    buildings: ["#1c2230", "#232b3b", "#161b26"],
    windows: "#5fe3ff",
    accent: "#22d3ee",
    hemiSky: "#9fc4ff",
    hemiGround: "#1a1f29",
    hemiIntensity: 1.1,
    sun: "#cfe6ff",
    sunIntensity: 1.6,
    trainTint: "#ffffff",
  },
  {
    id: "ferrugem",
    name: "Deserto Ferrugem",
    description: "Linha de carga no fim de tarde, poeira dourada e trilhos quentes.",
    free: true,
    sky: "#e8a868",
    fog: [40, 170],
    ground: "#9a6b43",
    gravel: "#b5845a",
    buildings: ["#a8673f", "#c07a4a", "#8a5232"],
    windows: "#ffd38a",
    accent: "#ff9a3c",
    hemiSky: "#ffd9b0",
    hemiGround: "#6b4528",
    hemiIntensity: 1.2,
    sun: "#ffd2a0",
    sunIntensity: 2.2,
    trainTint: "#ffe9d6",
  },
  {
    id: "glacial",
    name: "Estação Glacial",
    description: "Trilhos cobertos de neve sob um céu frio e limpo.",
    free: true,
    sky: "#cfe0ef",
    fog: [40, 160],
    ground: "#dfe8f1",
    gravel: "#c3d1de",
    buildings: ["#9fb6cc", "#b8cadb", "#8aa2ba"],
    windows: "#ffffff",
    accent: "#38bdf8",
    hemiSky: "#ffffff",
    hemiGround: "#9fb6cc",
    hemiIntensity: 1.1,
    sun: "#ffffff",
    sunIntensity: 2,
    trainTint: "#e6f2ff",
  },
  {
    id: "neblina",
    name: "Vale Neblina",
    description: "Ferrovia antiga atravessando uma floresta úmida e enevoada.",
    free: true,
    sky: "#5d7468",
    fog: [20, 120],
    ground: "#3a4a38",
    gravel: "#56604a",
    buildings: ["#2f4a33", "#3d5c40", "#264029"],
    windows: "#d8ffb0",
    accent: "#86efac",
    hemiSky: "#d6efd8",
    hemiGround: "#2a3627",
    hemiIntensity: 1.2,
    sun: "#fff4d6",
    sunIntensity: 1.5,
    trainTint: "#f0fff0",
  },
];

export const getMap = (id: string) => MAPS.find((m) => m.id === id) ?? MAPS[0]!;
