import kai from "@/assets/models/char-male-a.glb.asset.json";
import luna from "@/assets/models/char-female-a.glb.asset.json";
import dex from "@/assets/models/char-male-c.glb.asset.json";
import nia from "@/assets/models/char-female-c.glb.asset.json";
import unit7 from "@/assets/models/char-robot.glb.asset.json";
import zorp from "@/assets/models/char-alien.glb.asset.json";
import vex from "@/assets/models/char-knight.glb.asset.json";
import morbido from "@/assets/models/char-zombie.glb.asset.json";
import rasga from "@/assets/models/char-raider.glb.asset.json";
import tatico from "@/assets/models/char-soldier.glb.asset.json";
import theo from "@/assets/models/char-male-e.glb.asset.json";
import iara from "@/assets/models/char-female-e.glb.asset.json";

export interface CharacterDef {
  id: string;
  name: string;
  description: string;
  modelUrl: string;
  price: number;
  /** Free characters are available to everyone without an account. */
  free: boolean;
}

/**
 * Starting catalog. Prices are display values; purchases will be validated
 * by the server once accounts are connected.
 */
export const CHARACTERS: CharacterDef[] = [
  { id: "kai", name: "Kai", description: "Corredor de rua, rápido nas trocas de faixa.", modelUrl: kai.url, price: 0, free: true },
  { id: "luna", name: "Luna", description: "Sempre um passo à frente dos trens.", modelUrl: luna.url, price: 0, free: true },
  { id: "dex", name: "Dex", description: "Treinou nos pátios da madrugada.", modelUrl: dex.url, price: 0, free: true },
  { id: "nia", name: "Nia", description: "Equilíbrio perfeito nos saltos.", modelUrl: nia.url, price: 250, free: false },
  { id: "theo", name: "Theo", description: "Nunca perde o ritmo.", modelUrl: theo.url, price: 400, free: false },
  { id: "iara", name: "Iara", description: "Desliza por baixo de qualquer barreira.", modelUrl: iara.url, price: 600, free: false },
  { id: "tatico", name: "Tático", description: "Disciplina de operação especial.", modelUrl: tatico.url, price: 900, free: false },
  { id: "rasga", name: "Rasga", description: "Veio das linhas abandonadas do deserto.", modelUrl: rasga.url, price: 1200, free: false },
  { id: "morbido", name: "Mórbido", description: "Ninguém sabe como ele ainda corre.", modelUrl: morbido.url, price: 1500, free: false },
  { id: "unit7", name: "Unit-7", description: "Androide de manutenção que fugiu da garagem.", modelUrl: unit7.url, price: 2000, free: false },
  { id: "zorp", name: "Zorp", description: "Visitante de outra galáxia, curioso por trilhos.", modelUrl: zorp.url, price: 2600, free: false },
  { id: "vex", name: "Sir Vex", description: "Armadura pesada, coragem maior ainda.", modelUrl: vex.url, price: 3200, free: false },
];

export const getCharacter = (id: string) => CHARACTERS.find((c) => c.id === id) ?? CHARACTERS[0]!;
