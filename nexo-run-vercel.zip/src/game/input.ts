import type { Action } from "./sim/types";

/** Keyboard mapping (physical key codes). */
export function keyToAction(code: string): Action | null {
  switch (code) {
    case "KeyA":
    case "ArrowLeft":
      return "left";
    case "KeyD":
    case "ArrowRight":
      return "right";
    case "KeyW":
    case "ArrowUp":
    case "Space":
      return "jump";
    case "KeyS":
    case "ArrowDown":
      return "slide";
    default:
      return null;
  }
}

/** Swipe mapping in screen pixels (y grows downward). Returns null below the threshold. */
export function swipeToAction(dx: number, dy: number, threshold = 24): Action | null {
  if (Math.max(Math.abs(dx), Math.abs(dy)) < threshold) return null;
  if (Math.abs(dx) > Math.abs(dy)) return dx < 0 ? "left" : "right";
  return dy < 0 ? "jump" : "slide";
}
