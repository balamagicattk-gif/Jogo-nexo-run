import type { GameMode, RunResult } from "./sim/types";

export interface LocalEntry {
  mode: GameMode;
  value: number;
  coins: number;
  distance: number;
  at: string;
  characterId: string;
  mapId: string;
}

const KEY = "nexo-local-ranking-v1";
const MAX = 10;

export function readLocalRanking(): Record<GameMode, LocalEntry[]> {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore */
  }
  return { nocoin: [], score: [] };
}

/** Value that ranks a run: seconds without coins (No Coin) or points (Pontuação). */
export const rankValue = (r: RunResult) => (r.mode === "nocoin" ? r.noCoinTime : r.score);

/** Inserts a run; returns its 1-based position, or 0 when it didn't make the top 10. */
export function addLocalRun(r: RunResult, characterId: string, mapId: string): number {
  const all = readLocalRanking();
  const list = all[r.mode];
  const entry: LocalEntry = {
    mode: r.mode,
    value: rankValue(r),
    coins: r.coins,
    distance: Math.round(r.distance),
    at: new Date().toISOString(),
    characterId,
    mapId,
  };
  list.push(entry);
  list.sort((a, b) => b.value - a.value);
  const pos = list.indexOf(entry) + 1;
  all[r.mode] = list.slice(0, MAX);
  try {
    localStorage.setItem(KEY, JSON.stringify(all));
  } catch {
    /* ignore */
  }
  return pos <= MAX ? pos : 0;
}

export function formatTime(t: number) {
  if (t >= 60) {
    const m = Math.floor(t / 60);
    const s = t - m * 60;
    return `${m}:${s < 10 ? "0" : ""}${s.toFixed(2)}`;
  }
  return t.toFixed(2);
}
