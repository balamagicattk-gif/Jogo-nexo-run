import { useEffect, useState } from "react";
import { useSettings } from "./settings";

/** Loads saved preferences after hydration and reports when they are ready. */
export function useSettingsHydrated() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (useSettings.persist.hasHydrated()) {
      setReady(true);
      return;
    }
    const off = useSettings.persist.onFinishHydration(() => setReady(true));
    void useSettings.persist.rehydrate();
    return off;
  }, []);
  return ready;
}
