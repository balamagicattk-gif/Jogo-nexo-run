import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";

export interface MergedModel {
  geometry: THREE.BufferGeometry;
  material: THREE.Material | THREE.Material[];
  size: THREE.Vector3;
}

/**
 * Bakes every mesh of a static GLB into one geometry (with material groups) so it can be
 * drawn as a single InstancedMesh. Result sits on y=0, centered in x/z, scaled so its
 * length along z equals `targetLength`.
 */
export function mergeStaticModel(root: THREE.Object3D, targetLength: number): MergedModel {
  root.updateMatrixWorld(true);
  const geos: THREE.BufferGeometry[] = [];
  const mats: THREE.Material[] = [];
  root.traverse((o) => {
    const m = o as THREE.Mesh;
    if (!m.isMesh) return;
    const mList = Array.isArray(m.material) ? m.material : [m.material];
    let g = m.geometry.clone();
    g.applyMatrix4(m.matrixWorld);
    if (g.index) g = g.toNonIndexed();
    for (const name of Object.keys(g.attributes)) {
      if (name !== "position" && name !== "normal" && name !== "uv") g.deleteAttribute(name);
    }
    if (!g.attributes["uv"]) {
      const count = g.attributes["position"]!.count;
      g.setAttribute("uv", new THREE.BufferAttribute(new Float32Array(count * 2), 2));
    }
    if (!g.attributes["normal"]) g.computeVertexNormals();
    g.clearGroups();
    geos.push(g);
    mats.push(mList[0]!);
  });
  const merged = mergeGeometries(geos, true)!;
  merged.computeBoundingBox();
  const box = merged.boundingBox!;
  const size = new THREE.Vector3();
  box.getSize(size);
  const center = new THREE.Vector3();
  box.getCenter(center);
  merged.translate(-center.x, -box.min.y, -center.z);
  const s = targetLength / size.z;
  merged.scale(s, s, s);
  size.multiplyScalar(s);
  merged.computeBoundingSphere();
  return { geometry: merged, material: mats.length === 1 ? mats[0]! : mats, size };
}
