import * as THREE from "three";

function canvas(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return [c, c.getContext("2d")!] as const;
}

function finish(c: HTMLCanvasElement, repeatX = 1, repeatY = 1, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 4;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Speckled gravel. Deterministic so every load looks the same. */
export function gravelTexture(base: string, speck: string) {
  const [c, g] = canvas(256, 256);
  g.fillStyle = base;
  g.fillRect(0, 0, 256, 256);
  let seed = 7;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let i = 0; i < 2600; i++) {
    g.globalAlpha = 0.15 + rnd() * 0.45;
    g.fillStyle = rnd() > 0.5 ? speck : "#000000";
    const s = 1 + rnd() * 3;
    g.fillRect(rnd() * 256, rnd() * 256, s, s);
  }
  g.globalAlpha = 1;
  return finish(c, 6, 40);
}

/** Building facade: dark panels with a lit-window mask (used as emissive map). */
export function windowTextures(base: string) {
  const [c, g] = canvas(128, 256);
  const [e, ge] = canvas(128, 256);
  g.fillStyle = base;
  g.fillRect(0, 0, 128, 256);
  ge.fillStyle = "#000";
  ge.fillRect(0, 0, 128, 256);
  let seed = 11;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let y = 8; y < 256; y += 18) {
    for (let x = 8; x < 128; x += 20) {
      g.fillStyle = "rgba(0,0,0,0.35)";
      g.fillRect(x, y, 12, 10);
      if (rnd() < 0.45) {
        ge.fillStyle = `rgba(255,255,255,${0.4 + rnd() * 0.6})`;
        ge.fillRect(x, y, 12, 10);
      }
    }
  }
  g.fillStyle = "rgba(255,255,255,0.05)";
  g.fillRect(0, 0, 128, 3);
  return { map: finish(c, 1, 1), emissive: finish(e, 1, 1) };
}

/** Diagonal hazard stripes for barriers. */
export function stripeTexture(a: string, b: string) {
  const [c, g] = canvas(128, 32);
  g.fillStyle = a;
  g.fillRect(0, 0, 128, 32);
  g.fillStyle = b;
  for (let x = -32; x < 160; x += 32) {
    g.beginPath();
    g.moveTo(x, 32);
    g.lineTo(x + 16, 32);
    g.lineTo(x + 32, 0);
    g.lineTo(x + 16, 0);
    g.closePath();
    g.fill();
  }
  return finish(c, 1, 1);
}
