import { useGLTF } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import trackModel from "@/assets/models/track.glb.asset.json";
import type { MapDef } from "../content/maps";
import type { Runtime } from "../runtime";
import { LANE_WIDTH, laneX } from "../sim/constants";
import { mergeStaticModel } from "./mergeModel";
import { gravelTexture, windowTextures } from "./textures";

const VIEW = 170;
const tmp = new THREE.Object3D();

/** Sky color, fog and lights for the active map. */
export function Atmosphere({ map, shadows }: { map: MapDef; shadows: boolean }) {
  const sun = useRef<THREE.DirectionalLight>(null);
  useLayoutEffect(() => {
    if (sun.current) sun.current.target.position.set(0, 0, -20);
  }, []);
  return (
    <>
      <color attach="background" args={[map.sky]} />
      <fog attach="fog" args={[map.sky, map.fog[0], map.fog[1]]} />
      <hemisphereLight args={[map.hemiSky, map.hemiGround, map.hemiIntensity]} />
      <directionalLight
        ref={sun}
        position={[6, 14, 8]}
        intensity={map.sunIntensity}
        color={map.sun}
        castShadow={shadows}
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-12}
        shadow-camera-right={12}
        shadow-camera-top={12}
        shadow-camera-bottom={-12}
        shadow-camera-far={60}
      />
      <ambientLight intensity={0.35} />
    </>
  );
}

/** Scrolling gravel ground. */
export function Ground({ map, rt }: { map: MapDef; rt: React.RefObject<Runtime> }) {
  const tex = useMemo(() => gravelTexture(map.ground, map.gravel), [map]);
  useFrame(() => {
    tex.offset.y = (rt.current.state.dist / (VIEW + 40)) * 40;
  });
  return (
    <mesh rotation-x={-Math.PI / 2} position={[0, -0.02, -VIEW / 2 + 20]} receiveShadow>
      <planeGeometry args={[60, VIEW + 40]} />
      <meshStandardMaterial map={tex} roughness={0.95} />
    </mesh>
  );
}

/** Rails for the 3 lanes, recycled as the runner advances. */
export function Tracks({ rt }: { rt: React.RefObject<Runtime> }) {
  const gltf = useGLTF(trackModel.url);
  const merged = useMemo(() => mergeStaticModel(gltf.scene, 2), [gltf]);
  const seg = merged.size.z;
  const perLane = Math.ceil((VIEW + 20) / seg) + 1;
  const count = perLane * 3;
  const mesh = useRef<THREE.InstancedMesh>(null);
  const width = LANE_WIDTH * 0.92;
  useFrame(() => {
    const m = mesh.current;
    if (!m) return;
    const off = rt.current.state.dist % seg;
    let i = 0;
    for (let lane = 0; lane < 3; lane++) {
      for (let k = 0; k < perLane; k++) {
        tmp.position.set(laneX(lane), 0, 10 - k * seg + off);
        tmp.rotation.set(0, 0, 0);
        tmp.scale.set(width / merged.size.x, 1, 1);
        tmp.updateMatrix();
        m.setMatrixAt(i++, tmp.matrix);
      }
    }
    m.instanceMatrix.needsUpdate = true;
  });
  return <instancedMesh ref={mesh} args={[merged.geometry, merged.material, count]} receiveShadow frustumCulled={false} />;
}

/** Side buildings with lit windows plus lamp posts. Positions are seeded and recycled. */
export function Skyline({ map, rt, density }: { map: MapDef; rt: React.RefObject<Runtime>; density: number }) {
  const perSide = Math.round(24 * density);
  const spacing = (VIEW + 30) / perSide;
  const tex = useMemo(() => windowTextures(map.buildings[0] ?? "#222"), [map]);
  const layout = useMemo(() => {
    let seed = 1234;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    return Array.from({ length: perSide * 2 }, (_, i) => ({
      side: i % 2 === 0 ? -1 : 1,
      k: Math.floor(i / 2),
      w: 4 + rnd() * 4,
      d: spacing * (0.7 + rnd() * 0.25),
      h: 5 + rnd() * 18,
      x: 8.5 + rnd() * 4,
      color: new THREE.Color(map.buildings[Math.floor(rnd() * map.buildings.length)] ?? "#222"),
    }));
  }, [map, perSide, spacing]);
  const mesh = useRef<THREE.InstancedMesh>(null);
  const lamps = useRef<THREE.InstancedMesh>(null);
  const heads = useRef<THREE.InstancedMesh>(null);
  const lampCount = 12;
  const lampSpacing = (VIEW + 30) / (lampCount / 2);

  useLayoutEffect(() => {
    const m = mesh.current;
    if (!m) return;
    layout.forEach((b, i) => m.setColorAt(i, b.color));
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }, [layout]);

  useFrame(() => {
    const dist = rt.current.state.dist;
    const total = perSide * spacing;
    const m = mesh.current;
    if (m) {
      layout.forEach((b, i) => {
        const z = 20 - (((b.k * spacing - dist) % total) + total) % total;
        tmp.position.set(b.side * (b.x + b.w / 2), b.h / 2, z);
        tmp.rotation.set(0, 0, 0);
        tmp.scale.set(b.w, b.h, b.d);
        tmp.updateMatrix();
        m.setMatrixAt(i, tmp.matrix);
      });
      m.instanceMatrix.needsUpdate = true;
    }
    const lt = (lampCount / 2) * lampSpacing;
    for (let i = 0; i < lampCount; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const k = Math.floor(i / 2);
      const z = 20 - (((k * lampSpacing - dist) % lt) + lt) % lt;
      tmp.rotation.set(0, 0, 0);
      tmp.scale.set(1, 1, 1);
      tmp.position.set(side * 4.7, 2.2, z);
      tmp.updateMatrix();
      lamps.current?.setMatrixAt(i, tmp.matrix);
      tmp.position.set(side * 4.2, 4.4, z);
      tmp.updateMatrix();
      heads.current?.setMatrixAt(i, tmp.matrix);
    }
    if (lamps.current) lamps.current.instanceMatrix.needsUpdate = true;
    if (heads.current) heads.current.instanceMatrix.needsUpdate = true;
  });

  return (
    <>
      <instancedMesh ref={mesh} args={[undefined, undefined, layout.length]} frustumCulled={false}>
        <boxGeometry />
        <meshStandardMaterial map={tex.map} emissiveMap={tex.emissive} emissive={map.windows} emissiveIntensity={1.4} roughness={0.8} />
      </instancedMesh>
      <instancedMesh ref={lamps} args={[undefined, undefined, lampCount]} frustumCulled={false}>
        <boxGeometry args={[0.14, 4.4, 0.14]} />
        <meshStandardMaterial color="#2a2f3b" metalness={0.6} roughness={0.4} />
      </instancedMesh>
      <instancedMesh ref={heads} args={[undefined, undefined, lampCount]} frustumCulled={false}>
        <boxGeometry args={[1.1, 0.12, 0.3]} />
        <meshStandardMaterial color={map.accent} emissive={map.accent} emissiveIntensity={2.2} toneMapped={false} />
      </instancedMesh>
    </>
  );
}

useGLTF.preload(trackModel.url);
