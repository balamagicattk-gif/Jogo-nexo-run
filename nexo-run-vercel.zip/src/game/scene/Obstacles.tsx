import { useGLTF } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useMemo, useRef } from "react";
import * as THREE from "three";
import frontModel from "@/assets/models/train-electric-subway-a.glb.asset.json";
import midModel from "@/assets/models/train-electric-subway-b.glb.asset.json";
import backModel from "@/assets/models/train-electric-subway-c.glb.asset.json";
import type { MapDef } from "../content/maps";
import type { Runtime } from "../runtime";
import { BARRIER_HALF_WIDTH, CAR_LENGTH, HIGH_BARRIER_BOTTOM, LOW_BARRIER_TOP, laneX } from "../sim/constants";
import { mergeStaticModel } from "./mergeModel";
import { stripeTexture } from "./textures";

const tmp = new THREE.Object3D();
const MAX_CARS = 60;
const MAX_BARRIERS = 40;
const MAX_COINS = 160;
const hide = (m: THREE.InstancedMesh, from: number, to: number) => {
  tmp.position.set(0, -100, 0);
  tmp.scale.set(0, 0, 0);
  tmp.updateMatrix();
  for (let i = from; i < to; i++) m.setMatrixAt(i, tmp.matrix);
};

/** Trains drawn as three instanced car types (front, middle, back). */
export function Trains({ rt, map }: { rt: React.RefObject<Runtime>; map: MapDef }) {
  const a = useGLTF(frontModel.url);
  const b = useGLTF(midModel.url);
  const c = useGLTF(backModel.url);
  const cars = useMemo(
    () => [a, b, c].map((g) => mergeStaticModel(g.scene, CAR_LENGTH * 0.985)),
    [a, b, c],
  );
  const refs = [useRef<THREE.InstancedMesh>(null), useRef<THREE.InstancedMesh>(null), useRef<THREE.InstancedMesh>(null)];

  useFrame(() => {
    const s = rt.current.state;
    const n = [0, 0, 0];
    for (const o of s.obstacles) {
      if (o.kind !== "train") continue;
      const rel = o.z - s.dist;
      if (rel > 175 || rel + o.len < -15) continue;
      for (let i = 0; i < o.cars; i++) {
        const type = i === 0 ? 0 : i === o.cars - 1 ? 2 : 1;
        const m = refs[type]!.current;
        if (!m || n[type]! >= MAX_CARS) continue;
        const zc = o.z + (i + 0.5) * CAR_LENGTH - s.dist;
        tmp.position.set(laneX(o.lane), 0.12, -zc);
        tmp.rotation.set(0, Math.PI, 0);
        tmp.scale.set(1, 1, 1);
        tmp.updateMatrix();
        m.setMatrixAt(n[type]!++, tmp.matrix);
      }
    }
    refs.forEach((r, t) => {
      if (!r.current) return;
      hide(r.current, n[t]!, MAX_CARS);
      r.current.count = MAX_CARS;
      r.current.instanceMatrix.needsUpdate = true;
    });
  });

  return (
    <>
      {cars.map((m, i) => (
        <instancedMesh
          key={i}
          ref={refs[i]!}
          args={[m.geometry, m.material, MAX_CARS]}
          castShadow
          frustumCulled={false}
          onUpdate={(self) => {
            const mats = Array.isArray(self.material) ? self.material : [self.material];
            for (const mat of mats) (mat as THREE.MeshStandardMaterial).color?.set(map.trainTint);
          }}
        />
      ))}
    </>
  );
}

/** Low and overhead barriers. The simulation allows both jumping and sliding where clearance permits. */
export function Barriers({ rt, map }: { rt: React.RefObject<Runtime>; map: MapDef }) {
  const stripes = useMemo(() => stripeTexture("#11141b", map.accent), [map]);
  const boards = useRef<THREE.InstancedMesh>(null);
  const posts = useRef<THREE.InstancedMesh>(null);
  useFrame(() => {
    const s = rt.current.state;
    const bm = boards.current;
    const pm = posts.current;
    if (!bm || !pm) return;
    let nb = 0;
    let np = 0;
    for (const o of s.obstacles) {
      if (o.kind === "train") continue;
      const rel = o.z - s.dist;
      if (rel > 175 || rel < -15 || nb >= MAX_BARRIERS) continue;
      const x = laneX(o.lane);
      const z = -(rel + o.len / 2);
      const low = o.kind === "low";
      const boardH = low ? 0.42 : 0.55;
      const boardY = low ? LOW_BARRIER_TOP - boardH / 2 : HIGH_BARRIER_BOTTOM + boardH / 2;
      tmp.rotation.set(0, 0, 0);
      tmp.position.set(x, boardY, z);
      tmp.scale.set(BARRIER_HALF_WIDTH * 2, boardH, 1);
      tmp.updateMatrix();
      bm.setMatrixAt(nb++, tmp.matrix);
      const postH = low ? LOW_BARRIER_TOP : HIGH_BARRIER_BOTTOM + boardH + 0.1;
      for (const side of [-1, 1]) {
        tmp.position.set(x + side * (BARRIER_HALF_WIDTH - 0.08), postH / 2, z);
        tmp.scale.set(1, postH, 1);
        tmp.updateMatrix();
        pm.setMatrixAt(np++, tmp.matrix);
      }
    }
    hide(bm, nb, MAX_BARRIERS);
    hide(pm, np, MAX_BARRIERS * 2);
    bm.instanceMatrix.needsUpdate = true;
    pm.instanceMatrix.needsUpdate = true;
  });
  return (
    <>
      <instancedMesh ref={boards} args={[undefined, undefined, MAX_BARRIERS]} castShadow frustumCulled={false}>
        <boxGeometry args={[1, 1, 0.16]} />
        <meshStandardMaterial map={stripes} emissive={map.accent} emissiveIntensity={0.25} emissiveMap={stripes} roughness={0.5} />
      </instancedMesh>
      <instancedMesh ref={posts} args={[undefined, undefined, MAX_BARRIERS * 2]} castShadow frustumCulled={false}>
        <boxGeometry args={[0.12, 1, 0.12]} />
        <meshStandardMaterial color="#3a4150" metalness={0.7} roughness={0.35} />
      </instancedMesh>
    </>
  );
}

/** Spinning coins. */
export function Coins({ rt, color }: { rt: React.RefObject<Runtime>; color: string }) {
  const mesh = useRef<THREE.InstancedMesh>(null);
  useFrame(() => {
    const m = mesh.current;
    if (!m) return;
    const s = rt.current.state;
    const t = rt.current.renderTime;
    let n = 0;
    for (const c of s.coinList) {
      if (c.taken) continue;
      const rel = c.z - s.dist;
      if (rel > 150 || rel < -5 || n >= MAX_COINS) continue;
      tmp.position.set(laneX(c.lane), c.y + Math.sin(t * 3 + c.z) * 0.08, -rel);
      tmp.rotation.set(Math.PI / 2, t * 4 + c.z * 0.3, 0, "YXZ");
      tmp.scale.set(1, 1, 1);
      tmp.updateMatrix();
      m.setMatrixAt(n++, tmp.matrix);
    }
    hide(m, n, MAX_COINS);
    m.instanceMatrix.needsUpdate = true;
  });
  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, MAX_COINS]} frustumCulled={false}>
      <cylinderGeometry args={[0.36, 0.36, 0.09, 20]} />
      <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.45} metalness={0.85} roughness={0.25} />
    </instancedMesh>
  );
}

useGLTF.preload(frontModel.url);
useGLTF.preload(midModel.url);
useGLTF.preload(backModel.url);
