import { useFrame, useThree } from "@react-three/fiber";
import { useRef } from "react";
import * as THREE from "three";
import { mixer } from "../audio/mixer";
import type { Runtime } from "../runtime";
import { FIXED_DT } from "../sim/constants";
import { stepGame } from "../sim/engine";
import type { GameEvent } from "../sim/types";
import { useGameUi } from "../store";

const lookAt = new THREE.Vector3();
const camTarget = new THREE.Vector3();

interface Props {
  rt: React.RefObject<Runtime>;
  onEvents: (events: GameEvent[]) => void;
  onCrashSettled: () => void;
  onReady: () => void;
  fpsEl: React.RefObject<HTMLSpanElement | null>;
}

/**
 * The single per-frame driver: input → fixed-step simulation → events → camera → HUD.
 * Runs before draw components (negative priority).
 */
export function Stepper({ rt, onEvents, onCrashSettled, onReady, fpsEl }: Props) {
  const { camera, size } = useThree();
  const hudT = useRef(0);
  const fps = useRef({ frames: 0, t: 0 });
  const readySent = useRef(false);
  const shake = useRef(0);

  useFrame((_, rawDelta) => {
    const r = rt.current;
    const delta = Math.min(rawDelta, 0.1);
    r.renderTime += delta;
    const ui = useGameUi.getState();

    if (!readySent.current && r.runnerReady) {
      readySent.current = true;
      onReady();
    }

    if (ui.phase === "playing" && r.state.alive) {
      r.acc += delta;
      let guard = 0;
      while (r.acc >= FIXED_DT && guard++ < 8) {
        const acts = r.queue.splice(0, r.queue.length);
        for (const a of acts) r.log.push([r.state.step, a]);
        const ev = stepGame(r.state, acts);
        r.acc -= FIXED_DT;
        if (ev.length) {
          if (ev.some((e) => e.type === "crash")) shake.current = 0.45;
          onEvents(ev);
        }
        if (!r.state.alive) break;
      }
    }
    if (!r.state.alive && !r.finished) {
      r.crashT = r.crashT < 0 ? 0 : r.crashT + delta;
      if (r.crashT > 1.1) {
        r.finished = true;
        onCrashSettled();
      }
    }

    // Camera: behind and above, gently following lane and jump.
    const s = r.state;
    const portrait = size.width < size.height;
    const cam = camera as THREE.PerspectiveCamera;
    const fov = portrait ? 74 : 60;
    if (cam.fov !== fov) {
      cam.fov = fov;
      cam.updateProjectionMatrix();
    }
    camTarget.set(s.x * 0.55, (portrait ? 4.4 : 3.8) + s.y * 0.35, portrait ? 7.6 : 6.8);
    const k = 1 - Math.exp(-8 * delta);
    camera.position.lerp(camTarget, k);
    if (shake.current > 0) {
      shake.current = Math.max(0, shake.current - delta);
      camera.position.x += (Math.random() - 0.5) * shake.current * 0.6;
      camera.position.y += (Math.random() - 0.5) * shake.current * 0.6;
    }
    lookAt.set(s.x * 0.45, 1.3 + s.y * 0.25, -9);
    camera.lookAt(lookAt);

    // HUD at ~12 Hz
    hudT.current += delta;
    if (hudT.current > 0.08) {
      hudT.current = 0;
      const h = ui.hud;
      if (
        h.time !== s.time ||
        h.coins !== s.coins ||
        h.timerStopped !== s.timerStopped
      ) {
        ui.setHud({
          time: s.time,
          noCoinTime: s.noCoinTime,
          timerStopped: s.timerStopped,
          coins: s.coins,
          score: s.score,
          speed: s.speed,
        });
      }
    }

    // FPS
    fps.current.frames++;
    fps.current.t += rawDelta;
    if (fps.current.t >= 0.5) {
      if (fpsEl.current) fpsEl.current.textContent = `${Math.round(fps.current.frames / fps.current.t)} FPS`;
      fps.current.frames = 0;
      fps.current.t = 0;
    }
  }, -1);

  return null;
}

export { mixer };
