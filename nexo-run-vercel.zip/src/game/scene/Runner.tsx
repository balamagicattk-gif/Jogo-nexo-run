import { useAnimations, useGLTF } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { clone as cloneSkinned } from "three/examples/jsm/utils/SkeletonUtils.js";
import type { Runtime } from "../runtime";
import { PLAYER_HEIGHT } from "../sim/constants";

type Clip = "sprint" | "jump" | "crouch" | "die" | "idle";

/** Loads a rigged character, normalizes it to the runner's height and returns it with its clips. */
export function useCharacter(url: string) {
  const gltf = useGLTF(url);
  const scene = useMemo(() => {
    const s = cloneSkinned(gltf.scene);
    s.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true;
        m.frustumCulled = false;
      }
    });
    const box = new THREE.Box3().setFromObject(s);
    const h = box.max.y - box.min.y || 1;
    const k = PLAYER_HEIGHT / h;
    s.scale.setScalar(k);
    s.position.y = -box.min.y * k;
    return s;
  }, [gltf]);
  return { scene, animations: gltf.animations };
}

export function Runner({ rt, url }: { rt: React.RefObject<Runtime>; url: string }) {
  const group = useRef<THREE.Group>(null);
  const { scene, animations } = useCharacter(url);
  const { actions } = useAnimations(animations, group);
  const current = useRef<Clip | null>(null);

  const play = (name: Clip) => {
    if (current.current === name) return;
    const next = actions[name];
    if (!next) return;
    const prev = current.current ? actions[current.current] : null;
    next.reset();
    if (name === "die" || name === "jump") {
      next.setLoop(THREE.LoopOnce, 1);
      next.clampWhenFinished = true;
    }
    next.timeScale = name === "sprint" ? 1.25 : 1;
    next.fadeIn(0.08).play();
    prev?.fadeOut(0.08);
    current.current = name;
  };

  useEffect(() => {
    play("sprint");
    rt.current.runnerReady = true;
    return () => {
      rt.current.runnerReady = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [actions]);

  useFrame(() => {
    const s = rt.current.state;
    const g = group.current;
    if (!g) return;
    g.position.set(s.x, s.y, 0);
    const sliding = s.slideT > 0 && s.grounded;
    // Lean into lane changes.
    const lean = THREE.MathUtils.clamp((s.x - (s.lane - 1) * 2.2) * -0.18, -0.35, 0.35);
    g.rotation.set(0, Math.PI, lean);
    g.scale.set(1, sliding ? 0.55 : 1, 1);
    if (!s.alive) play("die");
    else if (!s.grounded) play("jump");
    else if (sliding) play("crouch");
    else play("sprint");
  });

  return (
    <group ref={group}>
      <primitive object={scene} />
    </group>
  );
}
