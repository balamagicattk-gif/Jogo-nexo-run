import { Environment, Lightformer } from "@react-three/drei";
import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import type { MapDef } from "../content/maps";
import type { Runtime } from "../runtime";
import type { Quality } from "../settings";
import type { GameEvent } from "../sim/types";
import { Barriers, Coins, Trains } from "./Obstacles";
import { Runner } from "./Runner";
import { Stepper } from "./Stepper";
import { Atmosphere, Ground, Skyline, Tracks } from "./World";

interface Props {
  rt: React.RefObject<Runtime>;
  map: MapDef;
  characterUrl: string;
  coinColor: string;
  quality: Quality;
  fpsEl: React.RefObject<HTMLSpanElement | null>;
  onEvents: (e: GameEvent[]) => void;
  onCrashSettled: () => void;
  onReady: () => void;
}

const DPR: Record<Quality, [number, number]> = { low: [0.75, 1], medium: [1, 1.5], high: [1, 2] };

export default function GameCanvas(p: Props) {
  const shadows = p.quality === "high";
  return (
    <Canvas
      shadows={shadows}
      dpr={DPR[p.quality]}
      camera={{ position: [0, 3.8, 6.8], fov: 60, near: 0.1, far: 220 }}
      gl={{ antialias: p.quality !== "low", powerPreference: "high-performance" }}
    >
      <Atmosphere map={p.map} shadows={shadows} />
      <Environment resolution={64}>
        <Lightformer intensity={1.6} position={[0, 6, 0]} rotation-x={Math.PI / 2} scale={[12, 12, 1]} />
        <Lightformer intensity={1} color={p.map.accent} position={[-6, 2, -2]} rotation-y={Math.PI / 2} scale={[20, 1.5, 1]} />
        <Lightformer intensity={0.8} color={p.map.sun} position={[6, 2, -2]} rotation-y={-Math.PI / 2} scale={[20, 1.5, 1]} />
      </Environment>
      <Ground map={p.map} rt={p.rt} />
      <Skyline map={p.map} rt={p.rt} density={p.quality === "low" ? 0.6 : 1} />
      <Barriers rt={p.rt} map={p.map} />
      <Coins rt={p.rt} color={p.coinColor} />
      {/* One boundary: the run only starts (runner ready) once trains and rails are drawn too. */}
      <Suspense fallback={null}>
        <Tracks rt={p.rt} />
        <Trains rt={p.rt} map={p.map} />
        <Runner rt={p.rt} url={p.characterUrl} />
      </Suspense>
      <Stepper rt={p.rt} fpsEl={p.fpsEl} onEvents={p.onEvents} onCrashSettled={p.onCrashSettled} onReady={p.onReady} />
    </Canvas>
  );
}
