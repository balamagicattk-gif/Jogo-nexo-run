import { createGame } from "./sim/engine";
import type { Action, GameMode, GameState, InputLogEntry } from "./sim/types";

/** Mutable per-run state shared by the stepper, input handlers and draw components. */
export interface Runtime {
  state: GameState;
  queue: Action[];
  log: InputLogEntry[];
  acc: number;
  /** Seconds since the crash (render time), or -1 while alive. */
  crashT: number;
  finished: boolean;
  runnerReady: boolean;
  renderTime: number;
}

export function newSeed() {
  const a = new Uint32Array(1);
  crypto.getRandomValues(a);
  return a[0] ?? 1;
}

export function createRuntime(mode: GameMode, seed = newSeed()): Runtime {
  return {
    state: createGame(seed, mode),
    queue: [],
    log: [],
    acc: 0,
    crashT: -1,
    finished: false,
    runnerReady: false,
    renderTime: 0,
  };
}
