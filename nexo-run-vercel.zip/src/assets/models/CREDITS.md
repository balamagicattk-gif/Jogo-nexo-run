# 3D model credits
All models by Kenney (https://kenney.nl), license CC0 1.0.
- char-*.glb — "Mini Characters" pack (https://kenney.nl/assets/mini-characters)
- train-*.glb, track.glb — "Train Kit" pack (https://kenney.nl/assets/train-kit)
