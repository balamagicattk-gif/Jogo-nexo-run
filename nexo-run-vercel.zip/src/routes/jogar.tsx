import { createFileRoute } from "@tanstack/react-router";
import { GameScreen } from "@/game/ui/GameScreen";
import { useSettingsHydrated } from "@/game/useSettingsHydrated";
import type { GameMode } from "@/game/sim/types";

export const Route = createFileRoute("/jogar")({
  ssr: false,
  validateSearch: (s: Record<string, unknown>): { modo: GameMode } => ({
    modo: s["modo"] === "score" ? "score" : "nocoin",
  }),
  head: () => ({
    meta: [
      { title: "Jogar · NEXO RUN" },
      { name: "description", content: "Corra pelos trilhos, desvie dos trens e bata seu recorde no NEXO RUN." },
      { property: "og:title", content: "Jogar · NEXO RUN" },
      { property: "og:description", content: "Corra pelos trilhos, desvie dos trens e bata seu recorde no NEXO RUN." },
    ],
  }),
  component: PlayPage,
});

function PlayPage() {
  const { modo } = Route.useSearch();
  const hydrated = useSettingsHydrated();
  if (!hydrated) return <div className="fixed inset-0 bg-background" />;
  return <GameScreen key={modo} mode={modo} />;
}
