import { createFileRoute, Link } from "@tanstack/react-router";
import { Coins, Timer } from "lucide-react";
import hero from "@/assets/hero-railyard.jpg";
import { NexoLogo } from "@/components/NexoLogo";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NEXO RUN · Run. Compete. Get verified." },
      { name: "description", content: "Corrida infinita 3D: desvie dos trens, pule barreiras e bata seu recorde nos modos No Coin e Pontuação." },
      { property: "og:title", content: "NEXO RUN · Run. Compete. Get verified." },
      { property: "og:description", content: "Corrida infinita 3D nos trilhos. Modos No Coin e Pontuação." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="relative min-h-screen overflow-hidden bg-background">
      <img src={hero} alt="" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover opacity-60" />
      <div className="absolute inset-0 bg-[image:var(--gradient-fade)]" />
      <div className="relative mx-auto flex min-h-screen max-w-3xl flex-col items-center justify-end gap-8 px-5 pb-16 text-center">
        <NexoLogo size="lg" />
        <p className="font-display text-sm uppercase tracking-[0.35em] text-muted-foreground">Run. Compete. Get verified.</p>
        <div className="grid w-full gap-4 sm:grid-cols-2">
          <div className="panel p-5 text-left">
            <h2 className="flex items-center gap-2 text-xl font-bold"><Timer className="size-5 text-primary" /> No Coin</h2>
            <p className="mt-1 text-sm text-muted-foreground">Fique o máximo de tempo sem pegar moedas. O cronômetro para na primeira.</p>
            <Button variant="hero" size="xl" className="mt-4 w-full" asChild>
              <Link to="/jogar" search={{ modo: "nocoin" }}>Jogar</Link>
            </Button>
          </div>
          <div className="panel p-5 text-left">
            <h2 className="flex items-center gap-2 text-xl font-bold"><Coins className="size-5 text-gold" /> Pontuação</h2>
            <p className="mt-1 text-sm text-muted-foreground">Some pontos pela distância e por cada moeda coletada.</p>
            <Button variant="hero" size="xl" className="mt-4 w-full" asChild>
              <Link to="/jogar" search={{ modo: "score" }}>Jogar</Link>
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">A/D ou ← → trocam de faixa · W, ↑ ou espaço pula · S ou ↓ desliza · No celular, deslize na tela.</p>
      </div>
    </main>
  );
}
