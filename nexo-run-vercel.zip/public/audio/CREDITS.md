# Audio credits
All sounds by Kenney (https://kenney.nl), license CC0 1.0.
- coin.mp3, jump.mp3, slide.mp3, lane.mp3, timer-stop.mp3, start.mp3 — "Digital Audio" pack (pepSound1, phaseJump1, lowDown, tone1, zapThreeToneDown, powerUp2)
- crash.mp3 — "Impact Sounds" pack (impactMetal_heavy_000)
