# NEXO RUN — primeira correção de mecânicas

Alterações feitas nesta versão:

1. Obstáculo baixo: o jogador pode passar deslizando ou pulando por cima.
2. Obstáculo alto/suspenso: o jogador pode passar deslizando por baixo ou pulando completamente por cima.
3. Trens: o jogador pode saltar do trilho para o teto, correr sobre o trem e saltar novamente para sair dele. Colisões laterais/frontais em altura insuficiente continuam causando derrota.
4. A altura do salto foi ajustada para permitir alcançar o teto dos trens.

Arquivos principais alterados:
- `src/game/sim/engine.ts`
- `src/game/sim/types.ts`
- `src/game/sim/constants.ts`
- `src/game/sim/engine.test.ts`
- `src/game/scene/Obstacles.tsx` (comentário atualizado)

Validação executada: simulação compilada do motor confirmou que os dois tipos de obstáculo aceitam salto e deslize, que o jogador consegue aterrissar no teto do trem e que consegue saltar do trem de volta aos trilhos. A suíte Vitest completa não foi executada porque as dependências do projeto não estavam instaladas neste ambiente.
