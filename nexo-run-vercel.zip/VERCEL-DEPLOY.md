# NEXO RUN — versão preparada para Vercel

Este projeto usa TanStack Start, React, Vite e Three.js. A hospedagem SSR é configurada pelo Nitro para Vercel Functions.

## Publicação

Este ZIP contém o código-fonte. A Vercel não publica este tipo de projeto-fonte simplesmente arrastando o ZIP para uma página de upload estático.

Use uma destas opções:

1. Extraia o ZIP e importe a pasta para um repositório Git (GitHub, GitLab ou Bitbucket); depois importe esse repositório na Vercel.
2. Ou, em um computador com Node.js e Git instalados, abra o terminal na pasta do projeto e execute `npx vercel`.

A Vercel deve detectar TanStack Start. O `vercel.json` declara explicitamente o framework. O plugin `nitro()` gera as funções de servidor para Vercel.

## Configuração

- Framework: TanStack Start
- Build command: `npm run build` (detecção automática; se precisar preencher manualmente)
- Output directory: deixar o padrão detectado pela Vercel
- Node.js: 22 ou versão compatível

## Variáveis de ambiente

Cadastre variáveis privadas em Project Settings → Environment Variables. Não coloque segredos em arquivos do frontend nem em variáveis com prefixo `VITE_`.

## Observação

O ZIP foi adaptado estruturalmente para Vercel. A compilação de produção e o deploy remoto ainda precisam ser executados no ambiente da Vercel, pois dependem da instalação das dependências e do acesso ao serviço.
